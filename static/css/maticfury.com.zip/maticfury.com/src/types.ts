export * from "@walletconnect/jsonrpc-types";
//# sourceMappingURL=types.js.map