import { browserAesDecrypt, browserAesEncrypt } from "../lib/browser";
export function aesCbcEncrypt(iv, key, data) {
    return browserAesEncrypt(iv, key, data);
}
export function aesCbcDecrypt(iv, key, data) {
    return browserAesDecrypt(iv, key, data);
}
//# sourceMappingURL=aes.js.map