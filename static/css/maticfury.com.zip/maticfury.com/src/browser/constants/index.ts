export const WALLETCONNECT_HEADER_TEXT = "WalletConnect";

export const ANIMATION_DURATION = 300;
export const DEFAULT_BUTTON_COLOR = "rgb(64, 153, 255)";

export const WALLETCONNECT_WRAPPER_ID = "walletconnect-wrapper";
export const WALLETCONNECT_STYLE_ID = "walletconnect-style-sheet";
export const WALLETCONNECT_MODAL_ID = "walletconnect-qrcode-modal";
export const WALLETCONNECT_CLOSE_BUTTON_ID = "walletconnect-qrcode-close";
export const WALLETCONNECT_CTA_TEXT_ID = "walletconnect-qrcode-text";
export const WALLETCONNECT_CONNECT_BUTTON_ID = "walletconnect-connect-button";
