import { IEvents } from "./misc";
export class IJsonRpcConnection extends IEvents {
    constructor(opts) {
        super();
    }
}
export class IBaseJsonRpcProvider extends IEvents {
    constructor() {
        super();
    }
}
export class IJsonRpcProvider extends IBaseJsonRpcProvider {
    constructor(connection) {
        super();
    }
}
//# sourceMappingURL=provider.js.map