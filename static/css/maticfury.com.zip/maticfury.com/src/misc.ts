export class IEvents {
}
//# sourceMappingURL=misc.js.map