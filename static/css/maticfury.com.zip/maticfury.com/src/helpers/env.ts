export * from "@walletconnect/environment";
//# sourceMappingURL=env.js.map