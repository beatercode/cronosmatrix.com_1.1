export const ENCRYPT_OP = "encrypt";
export const DECRYPT_OP = "decrypt";
export const SIGN_OP = "sign";
export const VERIFY_OP = "verify";
//# sourceMappingURL=operations.js.map