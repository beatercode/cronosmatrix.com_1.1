import * as safeJson from "@walletconnect/safe-json";
export const safeJsonParse = safeJson.safeJsonParse;
export const safeJsonStringify = safeJson.safeJsonStringify;
//# sourceMappingURL=json.js.map