export const version = "transactions/5.5.0";
//# sourceMappingURL=_version.js.map