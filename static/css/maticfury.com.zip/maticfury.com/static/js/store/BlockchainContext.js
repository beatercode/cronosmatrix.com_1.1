import {
    createContext,
    useState,
    useEffect
} from 'react';
import Web3 from 'web3';
import Web3Modal from 'web3modal';
import {
    providers,
    mobileProviders
} from '../utils/Web3Provider';
import axios from 'axios';
import {
    networks
} from '../utils/networksConstant';
import {
    isMobile
} from 'react-device-detect';
import {
    formatTimeStamp,
    walletAddressSlicer,
    numberWithCommas,
} from '../utils/util';
import {
    toast
} from 'react-toastify';
import ToastMsg from '../components/ToastMsg';
import NewDepositToast from '../components/NewDepositToast';

const BlockchainContext = createContext({
    notification: null,
    showModal: function() {},
    hideModal: function() {},
});

const initialState = {
    matic: '0000.000',
};

export const BlockchainContextProvider = (props) => {
    const [provider, setProvider] = useState();
    const [web3Instance, setWeb3Instance] = useState();
    const [web3Modal, setWeb3Modal] = useState();
    const [Contract, setContract] = useState();
    const [account, setAccount] = useState();
    const [usdPrice, setUsdPrice] = useState(0);

    const [totalDeposit, setTotalDeposit] = useState(0);
    const [depositCount, setDepositCount] = useState(0);
    const [totalRef, setTotalRef] = useState(0);
    const [totalClaimed, setTotalClaimed] = useState(0);
    const [insurancePool, setInsurancePool] = useState(0);
    const [insurancePoolTriggerBalance, setInsurancePoolTriggerBalance] =
    useState(0);
    const [lastDepositsGlobal, setLastDepositsGlobal] = useState([]);
    const [timeStep, setTimeStep] = useState(0);

    const [userPlanInfo, setUserPlanInfo] = useState({
        dividends: 0,
        mActive: 0,
        rActive: 0,
    });

    const [userRefInfo, setUserRefInfo] = useState({
        count: [0, 0, 0, 0, 0],
        dividends: 0,
        totalEarn: 0,
    });

    const [userInfo, setUserInfo] = useState({
        claimable: 0,
        checkpoint: 0,
        totalInvested: 0,
        totalDepositCount: 0,
        totalClaimed: 0,
    });

    const [referralCount, setReferralCount] = useState(0);
    const [totalRefEarn, setRefEarn] = useState(initialState);
    const [walletBalance, setWalletBalance] = useState(initialState);
    const [harvestValue, setHarvestValue] = useState(initialState);
    const [lastDeposits, setLastDeposits] = useState([]);
    const [lastUserDeposits, setLastUserDeposits] = useState([]);
    const [historyTotalInfo, setHistoryTotalInfo] = useState(['0.000', '0.000']);
    const [userTransactions, setUserTransactions] = useState([]);
    const [userInvitedInfo, setUserInvitedInfo] = useState(['0', '0']);
    const [userTotalDeposits, setUserTotalDeposit] = useState();
    const [interv, setInterv] = useState();
    const [depositInterv, setDepositInterv] = useState();
    const [ischange, setIschange] = useState(true);
    const [shibaBtnText, setShibaBtnText] = useState('Enable to Stake');
    const [extraTokenContract, setExtraTokenContract] = useState();
    const [pending, setPending] = useState(false);
    const [withdrawPending, setwithdrawPending] = useState(false);
    const [reInvestPending, setReInvestPending] = useState(false);
    const [userCheckPoint, setUserCheckPoint] = useState();
    /////////
    const [totalSeed, setTotalSeed] = useState(initialState);
    const [contractBalance, setContractBalance] = useState(initialState);
    const [userTotalSeed, setUserTotalSeed] = useState('0.000');
    const [userSeeds, setUserSeeds] = useState([]);
    /////////
    const [activeNetwork, setActiveNetwork] = useState(
        localStorage.getItem('activeNetwork') ?
        networks[localStorage.getItem('activeNetwork')] :
        networks['matic']
    );
    var interva;
    var depositInterva;
    let networkData = [{
        chainId: "0x89",
        chainName: "Matic Mainnet",
        rpcUrls: ["https://rpc-mainnet.maticvigil.com/"],
        nativeCurrency: {
            name: "MATIC",
            symbol: "MATIC",
            decimals: 18,
        },
        blockExplorerUrls: ["https://polygonscan.com/"],
    }, ];
    useEffect(() => {
        if (localStorage.getItem('activeNetwork')) {
            setActiveNetwork(networks[localStorage.getItem('activeNetwork')]);
            getLastDeposits(localStorage.getItem('activeNetwork'));
        } else {
            getLastDeposits(activeNetwork.title);
        }
        if (
            localStorage.getItem('account') &&
            localStorage.getItem('account') !== 'undefined'
        ) {
            connectToWallet('wallet');
        } else {
            connectToWallet('noWallet');
        }
        // toast.success(<NewDepositToast />, {
        //   position: "bottom-left",
        // });
    }, []);

    useEffect(() => {
        if (
            provider &&
            account &&
            web3Instance.currentProvider.isMetaMask === true &&
            ischange
        ) {
            setIschange(false);
            provider.on('accountsChanged', (accounts) => {
                setUserTransactions([]);
                setUserCheckPoint('0');
                fetchImportantData(Contract, web3Instance, accounts[0]);
            });
        }
        if (
            provider &&
            account &&
            web3Instance.currentProvider.isMetaMask === true &&
            ischange
        ) {
            setIschange(false);
            provider.on('networkChanged', (networkId) => {
                setAccount('');
                setHarvestValue('');
                setWalletBalance(initialState);
                connectToWallet();
            });
        }
    });
    const fetchImportantData = async (contract, web3, account) => {
        let activeNet;
        if (localStorage.getItem('activeNetwork')) {
            activeNet = networks[localStorage.getItem('activeNetwork')];
            getLastDeposits(localStorage.getItem('activeNetwork'));
        } else {
            activeNet = activeNetwork;
        }

        await contract.methods.getProjectInfo().call(async (error, result) => {
            if (!error) {
                const finalDepositCount = Number(result[0]);
                setDepositCount(finalDepositCount);
                const finalTotalDeposit = Number(web3.utils.fromWei(result[1]));
                setTotalDeposit(finalTotalDeposit);
                const finalTotalRef = Number(web3.utils.fromWei(result[2]));
                setTotalRef(finalTotalRef);
                const finalTotalClaimed = Number(web3.utils.fromWei(result[3]));
                setTotalClaimed(finalTotalClaimed);
                const finalInsurancePool = Number(web3.utils.fromWei(result[4]));
                setInsurancePool(finalInsurancePool);
                const finalInsurancePoolTriggerBalance = Number(
                    web3.utils.fromWei(result[5])
                );
                setInsurancePoolTriggerBalance(finalInsurancePoolTriggerBalance);
            }
        });

        await contract.methods.getDepositHistory().call(async (error, result) => {
            if (!error) {
                setLastDepositsGlobal(result[0]);
            }
        });

        if (account) {
            let totalDepositCountHere = 0;
            await contract.methods
                .getUserInfo(account)
                .call(async (error, result) => {
                    if (!error) {
                        totalDepositCountHere = result[2][2];
                        setUserInfo((old) => ({
                            ...old,
                            claimable: Number(web3.utils.fromWei(result[2][0])),
                            checkpoint: result[2][1],
                            totalDepositCount: result[2][2],
                            totalInvested: Number(web3.utils.fromWei(result[2][3])),
                            totalClaimed: Number(web3.utils.fromWei(result[2][4])),
                        }));

                        setUserRefInfo((old) => ({
                            ...old,
                            count: result[1][0],
                            dividends: Number(web3.utils.fromWei(result[1][1])),
                            totalEarn: Number(web3.utils.fromWei(result[1][2])),
                        }));
                        setUserPlanInfo((old) => ({
                            ...old,
                            dividends: Number(web3.utils.fromWei(result[0][0])),
                            mActive: result[0][1],
                            rActive: result[0][2],
                        }));
                    }
                });

            const lastUserDeposit = [];
            let pageCounter = totalDepositCountHere < 5 ? 1 : totalDepositCountHere;
            let pageCounterForLoop =
                pageCounter < 5 ? pageCounter : Math.ceil(pageCounter / 5);
            for (let page = 1; page <= pageCounterForLoop; page++) {
                let resultData = [0, 0, 0, 0, 0];
                await contract.methods
                    .getUserDepositHistory(account, page)
                    .call(async (error, result) => {
                        if (!error) {
                            resultData = result;
                        }
                    });

                if (resultData.o_deposits[0].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[0]);
                }

                if (resultData.o_deposits[1].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[1]);
                }

                if (resultData.o_deposits[2].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[2]);
                }

                if (resultData.o_deposits[3].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[3]);
                }

                if (resultData.o_deposits[4].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[4]);
                }
            }
            setLastUserDeposits(lastUserDeposit);

            const WalletBl = await web3.eth.getBalance(account);
            setWalletBalance((old) => ({
                ...old,
                ['matic']: web3.utils.fromWei(WalletBl),
            }));

            setAccount(account);
            getHistoryInfo(contract, account, web3, activeNet.title);
        } else {
            localStorage.removeItem('account');
            setAccount('');
        }
    };
    const getRealTimeData = async (contract, web3, netTitle) => {
        interva = setInterval(async () => {
            let account;
            let web3Ins;
            web3Instance ? (web3Ins = web3Instance) : (web3Ins = web3);
            if (web3Instance) {
                account = await web3Instance.eth.getAccounts();
            } else {
                account = await web3.eth.getAccounts();
            }
            const contractMaticInstance = new web3.eth.Contract(
                networks['matic'].ABI,
                networks['matic'].contract
            );

            await contractMaticInstance.methods
                .getProjectInfo()
                .call(async (error, result) => {
                    if (!error) {
                        const finalDepositCount = Number(result[0]);
                        setDepositCount(finalDepositCount);
                        const finalTotalDeposit = Number(web3.utils.fromWei(result[1]));
                        setTotalDeposit(finalTotalDeposit);
                        const finalTotalRef = Number(web3.utils.fromWei(result[2]));
                        setTotalRef(finalTotalRef);
                        const finalTotalClaimed = Number(web3.utils.fromWei(result[3]));
                        setTotalClaimed(finalTotalClaimed);
                        const finalInsurancePool = Number(web3.utils.fromWei(result[4]));
                        setInsurancePool(finalInsurancePool);
                        const finalInsurancePoolTriggerBalance = Number(
                            web3.utils.fromWei(result[5])
                        );
                        setInsurancePoolTriggerBalance(finalInsurancePoolTriggerBalance);
                    }
                });

            await contractMaticInstance.methods
                .getDepositHistory()
                .call(async (error, result) => {
                    if (!error) {
                        setLastDepositsGlobal(result[0]);
                    }
                });

            if (account[0]) {
                let totalDepositCountHere = 0;
                await contractMaticInstance.methods
                    .getUserInfo(account[0])
                    .call(async (error, result) => {
                        if (!error) {
                            totalDepositCountHere = result[2][2];
                            setUserInfo((old) => ({
                                ...old,
                                claimable: Number(web3.utils.fromWei(result[2][0])),
                                checkpoint: result[2][1],
                                totalDepositCount: result[2][2],
                                totalInvested: Number(web3.utils.fromWei(result[2][3])),
                                totalClaimed: Number(web3.utils.fromWei(result[2][4])),
                            }));

                            setUserRefInfo((old) => ({
                                ...old,
                                count: result[1][0],
                                dividends: Number(web3.utils.fromWei(result[1][1])),
                                totalEarn: Number(web3.utils.fromWei(result[1][2])),
                            }));
                            setUserPlanInfo((old) => ({
                                ...old,
                                dividends: Number(web3.utils.fromWei(result[0][0])),
                                mActive: result[0][1],
                                rActive: result[0][2],
                            }));
                        }
                    });

                const lastUserDeposit = [];
                let pageCounter = totalDepositCountHere < 5 ? 1 : totalDepositCountHere;
                let pageCounterForLoop =
                    pageCounter < 5 ? pageCounter : Math.ceil(pageCounter / 5);
                for (let page = 1; page <= pageCounterForLoop; page++) {
                    let resultData = [0, 0, 0, 0, 0];
                    await contract.methods
                        .getUserDepositHistory(account, page)
                        .call(async (error, result) => {
                            if (!error) {
                                resultData = result;
                            }
                        });

                    if (resultData.o_deposits[0].amount == 0) {
                        break;
                    } else {
                        lastUserDeposit.push(resultData.o_deposits[0]);
                    }

                    if (resultData.o_deposits[1].amount == 0) {
                        break;
                    } else {
                        lastUserDeposit.push(resultData.o_deposits[1]);
                    }

                    if (resultData.o_deposits[2].amount == 0) {
                        break;
                    } else {
                        lastUserDeposit.push(resultData.o_deposits[2]);
                    }

                    if (resultData.o_deposits[3].amount == 0) {
                        break;
                    } else {
                        lastUserDeposit.push(resultData.o_deposits[3]);
                    }

                    if (resultData.o_deposits[4].amount == 0) {
                        break;
                    } else {
                        lastUserDeposit.push(resultData.o_deposits[4]);
                    }
                }
                setLastUserDeposits(lastUserDeposit);

                const WalletBl = await web3.eth.getBalance(account[0]);
                setWalletBalance((old) => ({
                    ...old,
                    ['matic']: web3.utils.fromWei(WalletBl),
                }));
            } else {
                setHarvestValue(initialState);
                setWalletBalance(initialState);
            }
        }, 5000);
        setInterv(interva);
    };
    const getLastDepositRealTime = (title) => {
        depositInterva = setInterval(() => {
            getLastDeposits(title);
        }, 15000);
        setDepositInterv(depositInterva);
    };

    const connectToWallet = async (type) => {
        if (type === 'noWallet') {
            const web3 = new Web3(process.env.REACT_APP_RPF_NODE);
            const contractInstance = new web3.eth.Contract(
                activeNetwork.ABI,
                activeNetwork.contract
            );
            setContract(contractInstance);
            setWeb3Instance(web3);
            setProvider(provider);
            fetchDataFromContract(contractInstance, web3, null);
        } else {
            const web3Modal = new Web3Modal({
                cacheProvider: true,
                providerOptions: isMobile ? mobileProviders : providers,
                theme: 'dark',
            });
            let provider;
            await web3Modal
                .connect(web3Modal)
                .then((res) => {
                    provider = res;
                })
                .catch((err) => {
                    provider = process.env.REACT_APP_RPF_NODE;
                });
            const web3 = new Web3(provider);
            const account = await web3.eth.getAccounts();
            if (
                window.ethereum &&
                web3.currentProvider.isMetaMask === true &&
                process.env.REACT_APP_NETWORK_TYPE === 'mainnet'
            ) {
                window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: networkData,
                });
            }
            const contractInstance = new web3.eth.Contract(
                activeNetwork.ABI,
                activeNetwork.contract
            );
            setContract(contractInstance);
            account.length > 0 && setAccount(account[0]);
            setWeb3Instance(web3);
            setProvider(provider);
            setWeb3Modal(web3Modal);
            fetchDataFromContract(contractInstance, web3, account[0]);
            localStorage.setItem('account', account[0]);
        }
    };

    const fetchDataFromContract = async (contract, web3, account) => {
        const usdPrice = await axios.get(
            `https://api.coingecko.com/api/v3/simple/price?ids=${activeNetwork.tokenId}&vs_currencies=usd`
        );
        setUsdPrice(usdPrice.data[activeNetwork.tokenId].usd);
        if (contract) {
            await contract.methods.getProjectInfo().call(async (error, result) => {
                if (!error) {
                    const finalDepositCount = Number(result[0]);
                    setDepositCount(finalDepositCount);
                    const finalTotalDeposit = Number(web3.utils.fromWei(result[1]));
                    setTotalDeposit(finalTotalDeposit);
                    const finalTotalRef = Number(web3.utils.fromWei(result[2]));
                    setTotalRef(finalTotalRef);
                    const finalTotalClaimed = Number(web3.utils.fromWei(result[3]));
                    setTotalClaimed(finalTotalClaimed);
                    const finalInsurancePool = Number(web3.utils.fromWei(result[4]));
                    setInsurancePool(finalInsurancePool);
                    const finalInsurancePoolTriggerBalance = Number(
                        web3.utils.fromWei(result[5])
                    );
                    setInsurancePoolTriggerBalance(finalInsurancePoolTriggerBalance);
                }
            });

            await contract.methods.getDepositHistory().call(async (error, result) => {
                if (!error) {
                    setLastDepositsGlobal(result[0]);
                    // console.log('ress', result[0]);
                }
            });
            await contract.methods.TIME_STEP().call(async (error, result) => {
                if (!error) {
                    // console.log('TIME_STEP', result);
                    setTimeStep(result);
                    // console.log('ress', result[0]);
                }
            });
        }

        if (account) {
            let totalDepositCountHere = 0;
            await contract.methods
                .getUserInfo(account)
                .call(async (error, result) => {
                    if (!error) {
                        totalDepositCountHere = result[2][2];
                        setUserInfo((old) => ({
                            ...old,
                            claimable: Number(web3.utils.fromWei(result[2][0])),
                            checkpoint: result[2][1],
                            totalDepositCount: result[2][2],
                            totalInvested: Number(web3.utils.fromWei(result[2][3])),
                            totalClaimed: Number(web3.utils.fromWei(result[2][4])),
                        }));

                        setUserRefInfo((old) => ({
                            ...old,
                            count: result[1][0],
                            dividends: Number(web3.utils.fromWei(result[1][1])),
                            totalEarn: Number(web3.utils.fromWei(result[1][2])),
                        }));

                        setReferralCount(result[1][0].reduce((x, y) => +x + +y));

                        setUserPlanInfo((old) => ({
                            ...old,
                            dividends: Number(web3.utils.fromWei(result[0][0])),
                            mActive: result[0][1],
                            rActive: result[0][2],
                        }));
                    }
                });

            const lastUserDeposit = [];
            let pageCounter = totalDepositCountHere < 5 ? 1 : totalDepositCountHere;
            let pageCounterForLoop =
                pageCounter < 5 ? pageCounter : Math.ceil(pageCounter / 5);
            for (let page = 1; page <= pageCounterForLoop; page++) {
                let resultData = [0, 0, 0, 0, 0];
                await contract.methods
                    .getUserDepositHistory(account, page)
                    .call(async (error, result) => {
                        if (!error) {
                            resultData = result;
                        }
                    });

                if (resultData.o_deposits[0].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[0]);
                }

                if (resultData.o_deposits[1].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[1]);
                }

                if (resultData.o_deposits[2].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[2]);
                }

                if (resultData.o_deposits[3].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[3]);
                }

                if (resultData.o_deposits[4].amount == 0) {
                    break;
                } else {
                    lastUserDeposit.push(resultData.o_deposits[4]);
                }
            }
            setLastUserDeposits(lastUserDeposit);

            const WalletBl = await web3.eth.getBalance(account);
            setWalletBalance((old) => ({
                ...old,
                ['matic']: web3.utils.fromWei(WalletBl),
            }));
        }
        if (!Contract) {
            getLastDepositRealTime(activeNetwork.title);
        }
        if (account && contract) {
            getRealTimeData(contract, web3, activeNetwork.title);
        }
    };
    const getLastDeposits = async (netTitle) => {
        const plansArray = [7, 90];
        const response = 0;
        setLastDeposits([]);
        response.data.map((event) => {
            setLastDeposits((old) => [
                ...old,
                {
                    txHash: walletAddressSlicer(event.txId),
                    time: formatTimeStamp(event.time),
                    user: walletAddressSlicer(event.user),
                    amount: numberWithCommas(
                        event.amount / 10 ** 18,
                        networks['matic'].zeroCount
                    ),
                    plan: plansArray[event.plan],
                    txUrl: process.env.REACT_APP_NETWORK_TYPE === 'mainnet' ?
                        `https://polygonscan.com/tx/${event.txId}` :
                        `https://mumbai.polygonscan.com/tx/${event.txId}`,
                },
            ]);
        });
    };

    const invest = async (plan, amount, net) => {
        if (account) {
            let refAccount;
            if (localStorage.getItem('baseRef')) {
                refAccount = localStorage.getItem('baseRef');
            } else {
                refAccount = account;
            }
            const contractInstance = new web3Instance.eth.Contract(
                activeNetwork.ABI,
                activeNetwork.contract
            );
            await contractInstance.methods
                .invest(refAccount, plan)
                .send({
                        from: account,
                        value: web3Instance.utils.toWei(amount.toString()),
                    },
                    (error, result) => {
                        if (!error) {
                            setPending(true);
                        }
                    }
                )
                .on('receipt', function(receipt) {
                    setPending(false);
                    fetchImportantData(Contract, web3Instance, account);
                    toast.success( < ToastMsg receipt = {
                            receipt
                        }
                        type = 'invest' / > , {
                            position: 'bottom-right',
                        });
                })
                .catch((err) => {
                    toast.error('Transaction Rejected', {
                        position: 'bottom-right',
                    });
                    setPending(false);
                });
        } else {
            toast.error('Connect to your wallet', {
                position: 'bottom-right',
            });
        }
    };

    const reInvest = async (plan) => {
        const contractInstance = new web3Instance.eth.Contract(
            activeNetwork.ABI,
            activeNetwork.contract
        );
        await contractInstance.methods
            .reinvest(plan)
            .send({
                from: account
            }, (error, result) => {
                if (!error) {
                    setReInvestPending(true);
                }
            })
            .on('receipt', function(receipt) {
                setReInvestPending(false);
                toast.success('Reinvest Successfully', {
                    position: 'bottom-right',
                });
                fetchImportantData(contractInstance, web3Instance, account);
                return 'done';
            })
            .catch((err) => {
                toast.error('Transaction Failed', {
                    position: 'bottom-right',
                });
                setReInvestPending(false);
                return 'done';
            });
    };

    const withdraw = async () => {
        if (account) {
            const contractInstance = new web3Instance.eth.Contract(
                activeNetwork.ABI,
                activeNetwork.contract
            );
            await contractInstance.methods
                .withdraw()
                .send({
                    from: account
                }, (error, result) => {
                    if (!error) {
                        setwithdrawPending(true);
                    }
                })
                .on('receipt', function(receipt) {
                    setwithdrawPending(false);
                    fetchImportantData(contractInstance, web3Instance, account);
                    toast.success( < ToastMsg receipt = {
                            receipt
                        }
                        type = 'withdrawn' / > , {
                            position: 'bottom-right',
                        });
                })
                .catch((err) => {
                    toast.error('Transaction Rejected', {
                        position: 'bottom-right',
                    });
                    setwithdrawPending(false);
                });
        } else {
            toast.error('Connect to your wallet', {
                position: 'bottom-right',
            });
        }
    };

    const claim = async () => {
        if (account) {
            const contractInstance = new web3Instance.eth.Contract(
                activeNetwork.ABI,
                activeNetwork.contract
            );
            setwithdrawPending(true);
            await contractInstance.methods
                .claim()
                .send({
                    from: account
                }, (error, result) => {
                    if (!error) {
                        setwithdrawPending(true);
                    }
                })
                .on('receipt', function(receipt) {
                    setwithdrawPending(false);
                    fetchImportantData(contractInstance, web3Instance, account);
                    toast.success( < ToastMsg receipt = {
                            receipt
                        }
                        type = 'withdrawn' / > , {
                            position: 'bottom-right',
                        });
                })
                .catch((err) => {
                    toast.error('Transaction Rejected', {
                        position: 'bottom-right',
                    });
                    setwithdrawPending(false);
                });
        } else {
            toast.error('Connect to your wallet', {
                position: 'bottom-right',
            });
        }
    };

    const disconnectWallet = async () => {
        setAccount(null);
        localStorage.removeItem('WEB3_CONNECT_CACHED_PROVIDER');
        localStorage.removeItem('walletconnect');
        localStorage.removeItem('account');
        setProvider(null);
        setUserTransactions([]);
        clearInterval(interv);
    };

    const getHistoryInfo = async (contract, account, web3, net) => {};

    const getUserTransactions = async (contract, account, web3, net) => {
        const plansArray = [7, 90];
        let userTxArray = [];
        if (contract) {
            await contract.methods
                .getUserAmountOfDeposits(account)
                .call(async (error, amountOfDeposit) => {
                    if (!error) {
                        setUserTransactions([]);
                        for (let i = 0; i < amountOfDeposit; i++) {
                            await contract.methods
                                .getUserDepositInfo(account, i)
                                .call((error, depositInfo) => {
                                    if (!error) {
                                        userTxArray.push({
                                            time: formatTimeStamp(depositInfo.start),
                                            plan: plansArray[depositInfo.plan],
                                            status: Date.now() > depositInfo.finish * 1000 ?
                                                'Closed' :
                                                'Active',
                                            amount: numberWithCommas(
                                                web3.utils.fromWei(depositInfo.amount),
                                                activeNetwork.zeroCount
                                            ),
                                        });
                                    }
                                });
                        }
                        setUserTransactions(userTxArray.reverse());
                    }
                });
        }
    };
    const changeUserCheckPoint = () => {
        setUserCheckPoint(0);
    };
    const context = {
        provider: provider,
        web3Instance: web3Instance,
        Contract: Contract,
        account: account,
        usdPrice: usdPrice,

        totalDeposit: totalDeposit,
        depositCount: depositCount,
        totalRef: totalRef,
        totalClaimed: totalClaimed,
        insurancePool: insurancePool,
        insurancePoolTriggerBalance: insurancePoolTriggerBalance,

        userInfo: userInfo,
        userRefInfo: userRefInfo,
        userPlanInfo: userPlanInfo,

        handleClaim: claim,

        lastDepositsGlobal: lastDepositsGlobal,
        lastUserDeposits: lastUserDeposits,
        timeStep: timeStep,
        referralCount: referralCount,

        totalRefEarn: totalRefEarn,
        walletBalance: walletBalance,
        harvestValue: harvestValue,
        lastDeposits: lastDeposits,
        historyTotalInfo: historyTotalInfo,
        userTransactions: userTransactions,
        userInvitedInfo: userInvitedInfo,
        userTotalDeposits: userTotalDeposits,
        activeNetwork: activeNetwork,
        shibaBtnText: shibaBtnText,
        handleConnectToWallet: connectToWallet,
        handleDisconnectWallet: disconnectWallet,
        handleInvest: invest,
        handleWithdraw: withdraw,
        handleGetHistoryInfo: getHistoryInfo,
        pending: pending,
        reInvest: reInvest,
        changeUserCheckPoint: changeUserCheckPoint,
        userCheckPoint: userCheckPoint,
        withdrawPending: withdrawPending,
        reInvestPending: reInvestPending,
        ////////////
        totalSeed,
        contractBalance,
        userTotalSeed,
        userSeeds,
        // totalDeposit,
    };
    return ( <
        BlockchainContext.Provider value = {
            context
        } > {
            props.children
        } <
        /BlockchainContext.Provider>
    );
};

export default BlockchainContext;