import {
    useEffect,
    useState
} from 'react';
import axios from 'axios';
// import ContractModal from "./ContractModal";

const FooterSection = () => {
    const [links, setLinks] = useState();

    useEffect(() => {
        fetchLinks();
    }, []);

    const fetchLinks = async () => {
        const response = await axios.get('/config.json');
        setLinks(response.data.urls);
    };
    return ( <
        footer >
        <
        div className = 'footer-top' >
        <
        a target = '_blank'
        href = {
            links && links.telegram
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/telegram.png'
        alt = 'telegram'
        className = 'footer-bottom-img social' /
        >
        <
        /a> {
            /* <a target='_blank' href={links && links.twitter}>
                      <img
                        src='/assets/img/twitter.png'
                        alt='twitter'
                        className='footer-bottom-img social'
                      />
                    </a> */
        } <
        a target = '_blank'
        href = {
            links && links.dappradar
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/dappradar.png'
        alt = 'dapp radar'
        className = 'footer-bottom-img' /
        >
        <
        /a> <
        a className = 'footer-bsc'
        target = '_blank'
        href = {
            process.env.REACT_APP_MATIC_FACTOR_CONRACT
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/matic.png'
        alt = 'polygon'
        className = 'footer-bottom-img bsc' /
        >
        <
        /a> <
        a target = '_blank'
        href = {
            links && links.dapp
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/dapp-logo.png'
        alt = 'dapp'
        className = 'footer-bottom-img dapp-img' /
        >
        <
        /a> <
        a target = '_blank'
        href = {
            links && links.audit
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/haze.png'
        alt = 'haze crypto'
        className = 'footer-bottom-img haze' /
        >
        <
        /a> <
        a target = '_blank'
        href = {
            links && links.tech
        }
        rel = "noreferrer" >
        <
        img src = '/assets/img/tech.png'
        alt = 'haze crypto'
        className = 'footer-bottom-img trust-pilot' /
        >
        <
        /a> <
        /div> <
        div className = 'footer-bottom p-2' >
        <
        p > {
            process.env.REACT_APP_PROJECT_NAME
        }
        BLOCKCHAIN INVESTMENT PLATFORM {
            ' '
        } {
            process.env.REACT_APP_PROJECT_DOMAIN
        }, 2022 <
        /p> <
        /div> { /* {open && <ContractModal handleClose={() => setOpen(false)} />} */ } <
        /footer>
    );
};

export default FooterSection;