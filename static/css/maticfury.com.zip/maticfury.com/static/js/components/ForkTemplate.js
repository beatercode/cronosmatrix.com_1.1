import {
    useContext,
    useEffect,
    useState
} from 'react';
import axios from 'axios';
import {
    networks
} from '../utils/networksConstant';
import {
    numberWithCommas,
    timeDifference,
    walletAddressSlicer,
} from '../utils/util';
import BlockchainContext from '../store/BlockchainContext';
import Countdown from 'react-countdown';
import Spinner from '../assets/img/black-spin.svg';
import {
    toast
} from 'react-toastify';
import {
    CopyToClipboard
} from 'react-copy-to-clipboard/lib/Component';
import {
    formatTimeStamp
} from './../utils/util';

const dalilyProfit = [
    '20',
    '18.4',
    '17.1',
    '16.1',
    '15.2',
    '14.5',
    '14.0',
    '13.5',
    '13.0',
    '13.6',
    '13.3',
    '12.0',
    '11.7',
    '11.5',
    '11.3',
    '11.1',
    '10.9',
    '10.7',
    '10.6',
    '10.4',
    '10.3',
    '10.2',
    '10.1',
    '10.0',
];
const totalProfit = [
    '140.0',
    '146.9',
    '153.8',
    '160.7',
    '167.6',
    '174.5',
    '181.4',
    '188.3',
    '195.2',
    '202.1',
    '209.0',
    '215.9',
    '222.8',
    '229.7',
    '236.6',
    '243.5',
    '250.4',
    '257.3',
    '264.2',
    '271.1',
    '278.0',
    '284.9',
    '291.8',
    '298.7',
];

function ForkTemplate() {
    const {
        handleConnectToWallet,
        handleClaim,
        account,
        handleDisconnectWallet,
        walletBalance,
        activeNetwork,
        usdPrice,
        totalDeposit,
        depositCount,
        totalRef,
        totalClaimed,
        insurancePool,
        insurancePoolTriggerBalance,
        userInfo,
        userRefInfo,
        userPlanInfo,
        withdrawPending,
        handleInvest,
        pending,
        lastDepositsGlobal,
        lastUserDeposits,
        timeStep,
        referralCount,
    } = useContext(BlockchainContext);

    const [links, setLinks] = useState();
    const [periodRange, setPeriodRange] = useState(15);
    const [periodDays, setPeriodDays] = useState(15);
    const [amountOfDeposit, setAmountOfDeposit] = useState(networks.matic.min);
    const [disable, setDisable] = useState(false);

    const fetchLinks = async () => {
        const response = await axios.get('/config.json');
        setLinks(response.data.urls);
    };

    useEffect(() => {
        fetchLinks();
    }, []);

    useEffect(() => {
        setPeriodDays(Number(periodRange) + 7);
    }, [periodRange]);

    const rendererCountdown = ({
        days,
        hours,
        minutes,
        seconds,
        completed
    }) => {
        // completed ? <Completionist /> : <span>{days}d {hours}h {minutes}m {seconds}</span>;
        if (completed) {
            // Render a completed state
            setDisable(false);
            // changeUserCheckPoint(0);
            return '';
        } else {
            // Render a countdown
            setDisable(true);
            return ( <
                div id = 'clockdiv' >
                <
                div >
                <
                span > {
                    String(hours).padStart(2, '0')
                } < /span>: <
                span > {
                    String(minutes).padStart(2, '0')
                } < /span>: <
                span > {
                    String(seconds).padStart(2, '0')
                } < /span> <
                /div> <
                /div>
            );
        }
    };

    const handleSubmitForm = async (event) => {
        event.preventDefault();
        if (account) {
            if (amountOfDeposit >= +networks.matic.min) {
                handleInvest(periodRange, amountOfDeposit);
            } else {
                toast.error('Min amount is ' + networks.matic.min);
            }
        } else {
            toast.error('Connect to your wallet', {
                position: 'bottom-right',
            });
        }
    };

    return ( <
        >
        <
        div className = 'modal'
        id = 'exampleModalCenter'
        // tabIndex={-1}
        role = 'dialog'
        aria - labelledby = 'exampleModalCenterTitle'
        aria - hidden = 'true' >
        <
        div className = 'modal-dialog modal-dialog-centered'
        role = 'document' >
        <
        div className = 'modal-content' >
        <
        div className = 'modal-header' >
        <
        h5 className = 'modal-title'
        id = 'exampleModalLongTitle' >
        Modal title <
        /h5> <
        button type = 'button'
        className = 'close'
        data - dismiss = 'modal'
        aria - label = 'Close' >
        <
        span aria - hidden = 'true' > × < /span> <
        /button> <
        /div> <
        div className = 'modal-body' >
        <
        div className = 'deposit-history__content'
        id = 'depositHistoryLog' > {
            lastUserDeposits &&
            lastUserDeposits.map((item, index) => ( <
                div className = 'deposit-history__row'
                key = {
                    index
                } >
                <
                div className = 'deposit-history__item item-deposit-history' >
                <
                div className = 'item-deposit-history__name' > Amount < /div> <
                div className = 'item-deposit-history__value' > {
                    numberWithCommas(
                        item.amount / 1e18,
                        networks.matic.zeroCount
                    )
                } {
                    ' '
                } {
                    networks.matic.unit
                } <
                /div> <
                /div> <
                div className = 'deposit-history__item item-deposit-history' >
                <
                div className = 'item-deposit-history__name' > Plan < /div> <
                div className = 'item-deposit-history__value' > {
                    numberWithCommas(+item.planIdx + 7)
                }
                DAYS <
                /div> <
                /div> <
                div className = 'deposit-history__item item-deposit-history' >
                <
                div className = 'item-deposit-history__name' > Date < /div> <
                div className = 'item-deposit-history__value' > {
                    formatTimeStamp(+item.timeStart)
                } <
                /div> <
                /div> <
                /div>
            ))
        } <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        div id = 'blurredPreloadOverlay'
        style = {
            {
                display: 'none'
            }
        } >
        <
        div className = 'cell notSelectableText' >
        <
        div className = 'spinner' / >
        <
        br / >
        LOADING <
        br / >
        <
        small id = 'mainLoadingProgress' > fetching history < /small> <
        /div> <
        /div>

        <
        div id = 'overlayDialog'
        className = 'modal fade'
        tabIndex = {-1
        }
        role = 'dialog'
        style = {
            {
                display: 'none'
            }
        }
        aria - hidden = 'true' >
        <
        div className = 'modal-dialog modal-dialog-centered'
        role = 'document' >
        <
        div className = 'modal-content' >
        <
        div className = 'modal-header' >
        <
        h5 className = 'modal-title' > Welcome to BNBFire! < /h5> <
        /div> <
        div className = 'modal-body'
        style = {
            {
                textAlign: 'left'
            }
        } >
        <
        div className = 'welcomePopupText' >
        <
        b > Let us introduce the main Project advantages < /b> <
        br / >
        <
        br / >
        Generous and flexible financial model: From 10 % up to 20 % Daily ROI depending on the chosen Plan: you can Invest today and start Claiming your rewards immediately!
        <
        br / >
        <
        br / >
        Standalone Insurance contract that automatically balances the Project and protects our Users: the project is Reliable and your investments are Safe!
        <
        br / >
        <
        br / >
        Smart Referral Program with 5 Levels, named referral links and 24 - hour referral bound: the algorithm makes sure you will benefit from the people you invite and their referrals as well!
        <
        br / >
        <
        br / >
        We have also successfully passed the HazeCrypto security audit:
        everything has been checked and tested: the Project is fair,
        transparent and now proudly certified!
        <
        br / >
        <
        br / >
        Please feel free to join our community, participate and ask any questions!
        <
        /div> <
        /div> <
        div className = 'modal-footer' >
        <
        a href = '#'
        className = 'btn btn-info'
        id = 'welcomeInsuranceHint' >
        Insurance ?
        <
        /a> <
        a href = {
            links && links.telegram
        }
        target = '_blank'
        className = 'btn btn-info'
        data - dismiss = 'modal'
        rel = "noreferrer" >
        Telegram <
        /a> <
        a href = '#'
        className = 'btn btn-secondary'
        data - dismiss = 'modal' >
        Close <
        /a> <
        br / >
        <
        div id = 'b_welcomePopupDisable'
        data - dismiss = 'modal' >
        Don 't show again <
        /div> <
        /div> <
        /div> <
        /div> <
        /div>

        <
        div id = 'mainContentWrapper'
        className = 'wrapper'
        style = {
            {
                opacity: 0
            }
        } >
        <
        header className = 'header' >
        <
        div className = 'header__wrapper' >
        <
        a className = 'header__logo logo-header' >
        <
        div className = 'logo-header__image' >
        <
        picture >
        <
        img src = '/assets/img/icons/logo.png' / >
        <
        /picture> <
        /div> <
        div className = 'logo-header__text' > {
            networks.matic.unit
        } <
        span > Fury < /span> <
        /div> <
        /a> <
        div className = 'header__container' >
        <
        div className = 'headerCellCenter mobileHide' >
        <
        a href = 'about.pdf'
        target = '_blank'
        className = 'header__button button' >
        HOW TO START ?
        <
        /a> <
        /div> <
        div className = 'headerCellRight' > {
            account ? ( <
                button id = 'b_wallet_disconnect'
                className = 'header__button button'
                onClick = {
                    () => handleDisconnectWallet('wallet')
                } >
                Online: {
                    walletAddressSlicer(account)
                } <
                /button>
            ) : ( <
                button id = 'b_wallet_connect'
                className = 'header__button button'
                onClick = {
                    () => handleConnectToWallet()
                } >
                Connect Wallet <
                /button>
            )
        } <
        /div> <
        /div> <
        /div> <
        /header> <
        main className = 'page' >
        <
        section className = 'offer' >
        <
        div className = 'offer__container' >
        <
        div className = 'offer__top' >
        <
        a href = 'about.pdf'
        target = '_blank'
        className = 'header__button button' >
        HOW TO START ?
        <
        /a>

        {
            account ? ( <
                button id = 'b_wallet_disconnect'
                className = 'header__button button'
                onClick = {
                    () => handleDisconnectWallet('wallet')
                } >
                Online: {
                    walletAddressSlicer(account)
                } <
                /button>
            ) : ( <
                button id = 'b_wallet_connect'
                className = 'header__button button'
                onClick = {
                    () => handleConnectToWallet()
                } >
                Connect Wallet <
                /button>
            )
        } <
        /div> <
        div className = 'offer__content' >
        <
        div className = 'offer__text text-offer' >
        <
        div className = 'text-offer__title' >
        Stable & amp; Profitable Yield Farming Dapp With {
            ' '
        } <
        span >
        Automated Users Insurance <
        div id = 'headerInsuranceHint'
        className = 'mobileHide' >
        ?
        <
        /div> <
        /span> <
        /div> <
        div className = 'text-offer__subtitle' >
        <
        div >
        From < span > 10 % up to 20 % < /span> Daily ROI <
        /div> <
        div > 5 Levels of Referral Rewards < /div> <
        /div> <
        div className = 'text-offer__buttons' >
        <
        a href = '#anchor_yourAccount'
        className = 'text-offer__button button' >
        Deposit <
        /a> <
        a href = {
            links && links.telegram
        }
        target = '_blank'
        className = 'text-offer__button button-blue'
        rel = "noreferrer" >
        Telegram <
        /a> <
        a href = {
            links && links.audit
        }
        target = '_blank'
        className = 'text-offer__button button-blue'
        rel = "noreferrer" >
        Audit <
        /a> <
        a href = {
            process.env.REACT_APP_MATIC_FACTOR_CONRACT
        }
        target = '_blank'
        className = 'text-offer__button button-blue'
        rel = "noreferrer" >
        Contract <
        /a> <
        /div> <
        /div> <
        div className = 'offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/mainScreenImg.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/mainScreenImg.png' / >
        <
        /picture> <
        /div> <
        /div> <
        /div> <
        /section> <
        section className = 'totals' >
        <
        div className = 'totals__container' >
        <
        ul className = 'totals__list' >
        <
        li className = 'totals__object' >
        <
        div className = 'totals__item item-totals glowing'
        id = 'TOTAL_STACKED_VOLUME' >
        <
        div className = 'item-totals__title' >
        Total Staked Volume <
        /div> <
        div className = 'item-totals__BNB _BNB BNB' > {
            numberWithCommas(totalDeposit, networks.matic.zeroCount)
        } <
        /div> <
        div className = 'item-totals__USD _USD USD' > {
            numberWithCommas(totalDeposit * usdPrice, 2)
        } <
        /div> <
        div className = 'item-totals__bg' >
        <
        picture >
        <
        source srcSet = '/assets/img/totalsBg/01.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/totalsBg/01.png' / >
        <
        /picture> <
        /div> <
        /div> <
        div className = 'totals__text' >
        AVG {
            ' '
        } <
        span id = 'AVG_DEPOSIT' > {
            numberWithCommas(
                totalDeposit / depositCount,
                networks.matic.zeroCount
            )
        } <
        /span>{' '} {
            networks.matic.unit
        } in {
            ' '
        } <
        span id = 'TOTAL_DEPOSITS' > {
            numberWithCommas(depositCount)
        } <
        /span>{' '}
        Deposits <
        /div> <
        /li> <
        li className = 'totals__object' >
        <
        div className = 'totals__item item-totals glowing'
        id = 'INSURANCE_POOL' >
        <
        div className = 'item-totals__title' >
        Insurance Pool < div id = 'headerInsuranceHintTotals' > ? < /div> <
        /div> <
        div className = 'item-totals__BNB _BNB BNB' > {
            numberWithCommas(
                insurancePool,
                networks.matic.zeroCount
            )
        } <
        /div> <
        div className = 'item-totals__USD _USD USD' > {
            ' '
        } {
            numberWithCommas(insurancePool * usdPrice, 2)
        } <
        /div> <
        div className = 'item-totals__bg' >
        <
        picture >
        <
        source srcSet = '/assets/img/totalsBg/02.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/totalsBg/02.png' / >
        <
        /picture> <
        /div> <
        /div> <
        div className = 'totals__text' >
        TRIGGER BALANCE : {
            ' '
        } <
        span id = 'TRIGGER_BALANCE' > {
            numberWithCommas(
                insurancePoolTriggerBalance,
                networks.matic.zeroCount
            )
        } <
        /span>{' '} {
            networks.matic.unit
        } <
        /div> <
        /li> <
        li className = 'totals__object' >
        <
        div className = 'totals__item item-totals glowing'
        id = 'TOTAL_CLAIMED' >
        <
        div className = 'item-totals__title' >
        Total Claimed Rewards <
        /div> <
        div className = 'item-totals__BNB _BNB BNB' > {
            numberWithCommas(totalClaimed, networks.matic.zeroCount)
        } <
        /div> <
        div className = 'item-totals__USD _USD USD' > {
            numberWithCommas(totalClaimed * usdPrice, 2)
        } <
        /div> <
        div className = 'item-totals__bg' >
        <
        picture >
        <
        source srcSet = '/assets/img/totalsBg/03.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/totalsBg/03.png' / >
        <
        /picture> <
        /div> <
        /div> <
        div className = 'totals__text' >
        REFERRAL REWARDS : {
            ' '
        } <
        span id = 'EARNED_REFERRAL_REWARDS' > {
            numberWithCommas(totalRef, networks.matic.zeroCount)
        } <
        /span>{' '} {
            networks.matic.unit
        } <
        /div> <
        /li> <
        /ul> <
        /div> <
        /section> <
        section className = 'trade-offer mobileHide' >
        <
        div className = 'trade-offer__container' >
        <
        div className = 'trade-offer__title' >
        <
        span > The Best Way < /span> to Earn {networks.matic.unit} <
        /div> <
        ul className = 'trade-offer__list' >
        <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/01.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/01.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        Audited smartcontract <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        Tested and verified by HazeCrypto : fair, stable and reliable Project you can trust to <
        /div> <
        /div> <
        /li> <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/02.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/02.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        Income start from 10 % per day <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        Flexible architecture will be profitable
        for any investor :
        just choose your plan and Claim the profits!
        <
        /div> <
        /div> <
        /li> <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/03.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/03.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        Anti - Whale Features <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        Generosity is balanced by two simple rules : max 4 Claims per day, max {
            networks.matic.max
        } {
            ' '
        } <
        small > {
            networks.matic.unit
        } < /small> at once <
        /div> <
        /div> <
        /li> <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/04.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/04.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        5 - level referral program <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        Earn when people invited by you make deposits.You also benefit from their Referrals!
        <
        /div> <
        /div> <
        /li> <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/05.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/05.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        24 / 7 Support help <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        Feel free to ask any question in our group any time, we will be glad to help you!
        <
        /div> <
        /div> <
        /li> <
        li className = 'trade-offer__item item-trade-offer' >
        <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__image' >
        <
        picture >
        <
        source srcSet = '/assets/img/icons/tradeOffer/06.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/icons/tradeOffer/06.png' / >
        <
        /picture> <
        /div> <
        div className = 'item-trade-offer__title' >
        Automatic user insurance <
        /div> <
        /div> <
        div className = 'item-trade-offer__row' >
        <
        div className = 'item-trade-offer__text' >
        A special standalone contract guards the Project against balance draining and keeps it alive <
        /div> <
        /div> <
        /li> <
        /ul> <
        div className = 'trade-offer__start start-trade-offer mobileHide' >
        <
        div className = 'start-trade-offer__text' >
        <
        p > You stake < /p> <
        p > We pay < /p> <
        /div> <
        a href = 'about.pdf'
        target = '_blank'
        className = 'start-trade-offer__button button-cursor' >
        HOW TO START ?
        <
        /a> <
        /div> <
        /div> <
        /section> <
        section className = 'totals totals_second' >
        <
        div className = 'totals__container mobileHide' >
        <
        ul className = 'totals__list' >
        <
        li className = 'totals__object' >
        <
        div className = 'totals__item item-totals'
        id = 'TOTAL_STACKED_VOLUME' >
        <
        div className = 'item-totals__title' >
        Total Staked Volume <
        /div> <
        div className = 'item-totals__BNB _BNB BNB' > {
            numberWithCommas(totalDeposit, networks.matic.zeroCount)
        } <
        /div> <
        div className = 'item-totals__USD _USD USD' > {
            numberWithCommas(totalDeposit * usdPrice, 2)
        } <
        /div> <
        div className = 'item-totals__bg' >
        <
        picture >
        <
        source srcSet = '/assets/img/totalsBg/01.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/totalsBg/01.png' / >
        <
        /picture> <
        /div> <
        /div> <
        /li> <
        li className = 'totals__object' >
        <
        div className = 'totals__item item-totals'
        id = 'TOTAL_CLAIMED' >
        <
        div className = 'item-totals__title' >
        Total Claimed Rewards <
        /div> <
        div className = 'item-totals__BNB _BNB BNB' > {
            numberWithCommas(totalClaimed, networks.matic.zeroCount)
        } <
        /div> <
        div className = 'item-totals__USD _USD USD' > {
            ' '
        } {
            numberWithCommas(totalClaimed * usdPrice, 2)
        } <
        /div> <
        div className = 'item-totals__bg' >
        <
        picture >
        <
        source srcSet = '/assets/img/totalsBg/02.webp'
        type = 'image/webp' /
        >
        <
        img src = '/assets/img/totalsBg/02.png' / >
        <
        /picture> <
        /div> <
        /div> <
        /li> <
        li className = 'totals__object totals__object_restrictions' >
        <
        div className = 'totals__item item-totals item-totals_restrictions' >
        <
        div className = 'item-totals__title' > Restrictions < /div> <
        div className = 'item-totals__text' >
        <
        p >
        Claim : < span > every 6 hours < /span> <
        /p> <
        p >
        Max Claim: {
            networks.matic.max
        } {
            ' '
        } <
        span > {
            networks.matic.unit
        } < /span> <
        /p> <
        p >
        Excess dividends are sent back to the user 's account
        available
        for the next withdrawal. <
        /p> <
        /div> <
        /div> <
        /li> <
        /ul> <
        /div> <
        /section> <
        section className = 'main' >
        <
        div id = 'anchor_yourAccount' / >
        <
        div className = 'main__container' >
        <
        div className = 'main__column' >
        <
        div className = 'main__your-account your-account' >
        <
        div className = 'your-account__title' > YOUR ACCOUNT < /div> <
        div className = 'your-account__row' >
        <
        div className = 'your-account__item item-your-account'
        id = 'USER_BALANCE' >
        <
        div className = 'item-your-account__title' >
        WALLET BALANCE <
        /div> <
        div className = 'item-your-account__BNB _BNB BNB' > {
            numberWithCommas(
                walletBalance['matic'],
                activeNetwork.zeroCount
            )
        } <
        /div> <
        div className = 'item-your-account__USD _USD USD' > {
            numberWithCommas(walletBalance['matic'] * usdPrice, 2)
        } <
        /div> <
        /div> <
        div className = 'your-account__item item-your-account' >
        <
        div className = 'item-your-account__title' >
        ACTUAL INFO <
        /div> <
        div className = 'item-your-account__table table-item-your-account'
        id = 'USER_ACTUAL' >
        <
        div className = 'table-item-your-account__row' >
        <
        div className = 'table-item-your-account__cell-name' >
        Active Plans:
        <
        /div> <
        div className = 'table-item-your-account__cell-value ACTIVE' > {
            numberWithCommas(+userPlanInfo.mActive)
        } <
        /div> <
        /div> <
        div className = 'table-item-your-account__row' >
        <
        div className = 'table-item-your-account__cell-name' >
        Referrals count:
        <
        /div> <
        div className = 'table-item-your-account__cell-value REFCOUNT' > {
            numberWithCommas(referralCount)
        } <
        /div> <
        /div> <
        div className = 'table-item-your-account__row' >
        <
        div className = 'table-item-your-account__cell-name' >
        Claim Cooldown:
        <
        /div> <
        div className = 'table-item-your-account__cell-value COOLDOWN' > {
            (Number(userInfo.checkpoint) + timeStep / 4) *
            1000 >
            +new Date() ? ( <
                Countdown date = {
                    (Number(userInfo.checkpoint) + timeStep / 4) *
                    1000
                }
                renderer = {
                    rendererCountdown
                }
                />
            ) : account ? ( <
                > Claimable < />
            ) : ( <
                > No Data < />
            )
        } <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        div className = 'your-account__row' >
        <
        div className = 'your-account__item item-your-account'
        id = 'USER_CLAIMABLE' >
        <
        div className = 'item-your-account__title' > {
            networks.matic.unit
        }
        TO CLAIM <
        /div> <
        div className = 'item-your-account__BNB _BNB BNB' > {
            numberWithCommas(
                userInfo.claimable,
                networks.matic.zeroCount
            )
        } <
        /div> <
        div className = 'item-your-account__USD _USD USD' > {
            numberWithCommas(userInfo.claimable * usdPrice, 2)
        } <
        /div> <
        button className = 'item-your-account__button button offlineDisabled'
        id = 'b_claim'
        disabled = {
            withdrawPending ||
            (Number(userInfo.checkpoint) + timeStep / 4) * 1000 >
            +new Date() ?
            true :
                ''
        }
        onClick = {
            () => handleClaim()
        } > {
            withdrawPending ? ( <
                >
                <
                img src = {
                    Spinner
                }
                className = 'farm-spinner' / > {
                    ' '
                }
                Pending...
                <
                />
            ) : ( <
                > CLAIM < />
            )
        } <
        /button> <
        /div> <
        div className = 'your-account__item item-your-account'
        id = 'USER_TOTAL_INVESTED' >
        <
        div className = 'item-your-account__title' >
        TOTAL STAKED <
        /div> <
        div className = 'item-your-account__BNB _BNB BNB' > {
            numberWithCommas(
                userInfo.totalInvested,
                networks.matic.zeroCount
            )
        } <
        /div> <
        div className = 'item-your-account__USD _USD USD' > {
            numberWithCommas(userInfo.totalInvested * usdPrice, 2)
        } <
        /div> <
        button className = 'item-your-account__button button offlineDisabled'
        id = 'b_userHistory'
        data - numback = {
            1
        }
        // disabled='disabled'
        type = 'button'
        data - toggle = 'modal'
        data - target = '#exampleModalCenter' >
        HISTORY <
        /button> <
        /div> <
        /div> <
        /div> <
        div className = 'main__stake stake'
        id = 'panel_stake' >
        <
        div className = 'stake__title' >
        STAKE {
            networks.matic.unit
        } <
        /div> <
        div className = 'stake__subtitle' >
        Stable & amp; Profitable Yield Farming <
        /div> <
        div className = 'stake__deposit-period deposit-period-stake' >
        <
        div className = 'deposit-period-stake__title' >
        Deposit period(days):
        <
        /div> <
        div className = 'deposit-period-stake__range range' >
        <
        div className = 'range__wrap' >
        <
        div className = 'range__value'
        id = 'rangeValue'
        style = {
            {
                left: `calc(${(periodRange / 23) * 100}% - 5px)`,
            }
        } >
        <
        span > {
            periodDays
        } < /span> <
        /div> <
        div className = 'range__value-lower'
        id = 'rangeValueLower'
        style = {
            {
                width: `calc(${(periodRange / 23) * 100}% - 5px)`,
            }
        }
        /> <
        input type = 'range'
        min = {
            0
        }
        max = {
            23
        }
        step = {
            1
        }
        className = 'range__input _more'
        id = 'range'
        value = {
            periodRange
        }
        onChange = {
            (e) => setPeriodRange(e.target.value)
        }
        /> <
        /div> <
        span className = 'range__min' > 7 < /span> <
        span className = 'range__max' > 30 < /span> <
        /div> <
        div className = 'deposit-period-stake__info' >
        <
        div className = 'deposit-period-stake__daily-ROI' >
        <
        div className = 'deposit-period-stake__daily-ROI-text' >
        Daily ROI:
        <
        /div> <
        div className = 'deposit-period-stake__daily-ROI-value'
        id = 'ROI' > {
            dalilyProfit[periodDays - 7]
        } %
        <
        /div> <
        /div> <
        div className = 'deposit-period-stake__total-profit' >
        <
        div className = 'deposit-period-stake__total-profit-text' >
        Total Profit:
        <
        /div> <
        div className = 'deposit-period-stake__total-profit-value'
        id = 'total-profit' > {
            totalProfit[periodDays - 7]
        } %
        <
        /div> <
        /div> <
        div className = 'deposit-period-stake__earnings' >
        <
        div className = 'deposit-period-stake__earnings-text' >
        In <
        /div> <
        div className = 'deposit-period-stake__earnings-days'
        id = 'day' > {
            periodDays
        } <
        /div> <
        div className = 'deposit-period-stake__earnings-text' >
        days you will earn:
        <
        /div> <
        div className = 'deposit-period-stake__earnings-value'
        id = 'earnings' > {
            numberWithCommas(
                (amountOfDeposit *
                    Number(totalProfit[periodDays - 7])) /
                100,
                4
            )
        } <
        /div> <
        /div> <
        /div> <
        /div> <
        div className = 'stake__deposit-amount deposit-amount-stake' >
        <
        div className = 'deposit-amount-stake__title' >
        Deposit amount:
        <
        /div> <
        div className = 'deposit-amount-stake__body' >
        <
        div className = 'deposit-amount-stake__input input-deposit-amount-stake' >
        <
        input autoComplete = 'off'
        type = 'text'
        name = 'form[]'
        id = 'stakeAmount'
        value = {
            amountOfDeposit
        }
        onChange = {
            (e) => setAmountOfDeposit(e.target.value)
        }
        /> {
            /* <button
                                      type='button'
                                      className='input-deposit-amount-stake__button'
                                      id='b_max'>
                                      MAX
                                    </button> */
        } <
        /div>

        <
        button className = 'deposit-amount-stake__button button offlineDisabled'
        id = 'b_stake'
        disabled = {
            pending ? true : ''
        }
        onClick = {
            handleSubmitForm
        } > {
            pending ? ( <
                >
                <
                img src = {
                    Spinner
                }
                className = 'spinner' / >
                <
                />
            ) : ( <
                > STAKE < />
            )
        } <
        /button> <
        div className = 'deposit-amount-stake__text' >
        Minimum: < span > {
            networks.matic.min
        } < /span> <
        span > {
            networks.matic.unit
        } < /span> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        div className = 'main__column' >
        <
        div className = 'main__deposit-history deposit-history' >
        <
        div className = 'deposit-history__title' > DEPOSIT HISTORY < /div> <
        div className = 'deposit-history__subtitle' >
        Total deposit count: {
            ' '
        } <
        span id = 'depositHistoryCount' > {
            numberWithCommas(depositCount)
        } <
        /span> <
        /div> <
        div className = 'deposit-history__content'
        id = 'depositHistoryLog' > {
            lastDepositsGlobal &&
            lastDepositsGlobal
            .slice(0)
            .reverse()
            .map(
                (item, index) =>
                Number(item.amount) > 0 && ( <
                    div className = 'deposit-history__row'
                    key = {
                        index
                    } >
                    <
                    div className = 'deposit-history__item item-deposit-history' >
                    <
                    div className = 'item-deposit-history__name' >
                    Invested <
                    /div> <
                    div className = 'item-deposit-history__value' > {
                        timeDifference(item.timestamp)
                    } <
                    /div> <
                    /div> <
                    div className = 'deposit-history__item item-deposit-history' >
                    <
                    div className = 'item-deposit-history__name' >
                    Plan <
                    /div> <
                    div className = 'item-deposit-history__value' > {
                        numberWithCommas(item.duration / timeStep)
                    } {
                        ' '
                    }
                    DAYS <
                    /div> <
                    /div> <
                    div className = 'deposit-history__item item-deposit-history' >
                    <
                    div className = 'item-deposit-history__name' >
                    Amount <
                    /div> <
                    div className = 'item-deposit-history__value' > {
                        numberWithCommas(
                            item.amount / 1e18,
                            networks.matic.zeroCount
                        )
                    } {
                        ' '
                    } {
                        networks.matic.unit
                    } <
                    /div> <
                    /div> <
                    /div>
                )
            )
        } <
        /div> <
        /div> <
        /div> <
        /div> <
        /section> <
        section className = 'referral' >
        <
        div className = 'referral__container' >
        <
        div className = 'referral__program referral-program'
        id = 'USER_TOTAL_REF_EARNED' >
        <
        div className = 'referral-program__title' > REFERRAL PROGRAM < /div> <
        div className = 'referral-program__subtitle' >
        Stake atleast once to receive referral rewards!
        <
        /div> <
        ul className = 'referral-program__levels levels-referral-program' >
        <
        li className = 'levels-referral-program__item' >
        <
        div className = 'levels-referral-program__info' >
        <
        div className = 'levels-referral-program__title' >
        Level 1 <
        /div> <
        div className = 'levels-referral-program__percent' > 7 % < /div> <
        /div> <
        div className = 'levels-referral-program__referrals'
        id = 'refCount0' > {
            numberWithCommas(userRefInfo.count[0])
        } <
        /div> <
        /li> <
        li className = 'levels-referral-program__item' >
        <
        div className = 'levels-referral-program__info levels-referral-program__info_30' >
        <
        div className = 'levels-referral-program__title' >
        Level 2 <
        /div> <
        div className = 'levels-referral-program__percent' > 3 % < /div> <
        /div> <
        div className = 'levels-referral-program__referrals'
        id = 'refCount1' > {
            numberWithCommas(userRefInfo.count[1])
        } <
        /div> <
        /li> <
        li className = 'levels-referral-program__item' >
        <
        div className = 'levels-referral-program__info levels-referral-program__info_20' >
        <
        div className = 'levels-referral-program__title' >
        Level 3 <
        /div> <
        div className = 'levels-referral-program__percent' > 2 % < /div> <
        /div> <
        div className = 'levels-referral-program__referrals'
        id = 'refCount2' > {
            numberWithCommas(userRefInfo.count[2])
        } <
        /div> <
        /li> <
        li className = 'levels-referral-program__item' >
        <
        div className = 'levels-referral-program__info levels-referral-program__info_10' >
        <
        div className = 'levels-referral-program__title' >
        Level 4 <
        /div> <
        div className = 'levels-referral-program__percent' > 1 % < /div> <
        /div> <
        div className = 'levels-referral-program__referrals'
        id = 'refCount3' > {
            numberWithCommas(userRefInfo.count[3])
        } <
        /div> <
        /li> <
        li className = 'levels-referral-program__item' >
        <
        div className = 'levels-referral-program__info levels-referral-program__info_5' >
        <
        div className = 'levels-referral-program__title' >
        Level 5 <
        /div> <
        div className = 'levels-referral-program__percent' >
        0.5 %
        <
        /div> <
        /div> <
        div className = 'levels-referral-program__referrals'
        id = 'refCount4' > {
            numberWithCommas(userRefInfo.count[4])
        } <
        /div> <
        /li> <
        /ul> <
        div className = 'referral-program__subtitle' > TOTAL REWARDS < /div> <
        div className = 'referral-program__BNB _BNB BNB' > {
            numberWithCommas(
                userRefInfo.totalEarn,
                networks.matic.zeroCount
            )
        } <
        /div> <
        div className = 'referral-program__USD _USD USD' > {
            numberWithCommas(userRefInfo.totalEarn * usdPrice, 2)
        } <
        /div> <
        div className = 'referral-program__referal-link referal-link-referral-program' > {
            account && userInfo.totalInvested > 0 ? ( <
                >
                <
                div className = 'referal-link-referral-program__title' >
                <
                br / >
                Your referal link <
                /div> <
                small >
                Note: reflink will not
                function until you make your first investment <
                /small> <
                input id = 'referralLinkInput'
                type = 'text'
                readOnly placeholder = {
                    `https://${window.location.host}/?ref=${account}`
                }
                autoComplete = 'off'
                className = 'referal-link-referral-program__link offlineDisabled'
                disabled = '' /
                >

                <
                CopyToClipboard text = {
                    `https://${window.location.host}/?ref=${account}`
                }
                onCopy = {
                    () => {
                        toast.success('personal link Copied Successfully');
                    }
                } >
                <
                button className = 'referal-link-referral-program__button button'
                id = 'b_copyLink'
                disabled = '' >
                COPY <
                /button> <
                /CopyToClipboard> <
                />
            ) : ( <
                >
                <
                div className = 'referal-link-referral-program__title' >
                <
                br / >
                Your referal link <
                /div> <
                small >
                Note: reflink will not
                function until you make your first investment <
                /small> <
                input id = 'referralLinkInput'
                type = 'text'
                readOnly placeholder = 'You will get your ref link after investing'
                autoComplete = 'off'
                className = 'referal-link-referral-program__link offlineDisabled'
                disabled = 'disabled' /
                >

                <
                CopyToClipboard text = {
                    `https://${window.location.host}`
                }
                onCopy = {
                    () => {
                        toast.success('personal link Copied Successfully');
                    }
                } >
                <
                button className = 'referal-link-referral-program__button button offlineDisabled'
                id = 'b_copyLink'
                disabled = 'disabled' >
                COPY <
                /button> <
                /CopyToClipboard> <
                />
            )
        } <
        br / >
        <
        /div> <
        /div> <
        div className = 'referral__system referral-system mobileHide' >
        <
        ul className = 'referral-system__steps' >
        <
        li className = 'referral-system__step' >
        <
        p > Make a minimum deposit < /p> <
        img src = '/assets/img/icons/arrowRed.svg' / >
        <
        /li> <
        li className = 'referral-system__step' >
        <
        p > Get your referral link < /p> <
        img src = '/assets/img/icons/arrowBlue.svg' / >
        <
        /li> <
        li className = 'referral-system__step' >
        <
        p > Send it to your friends < /p> <
        img src = '/assets/img/icons/arrowRed.svg' / >
        <
        /li> <
        li className = 'referral-system__step' >
        <
        p > Enjoy your profit < /p> <
        /li> <
        /ul> <
        /div> <
        /div> <
        /section> <
        /main> <
        /div> <
        />
    );
}

export default ForkTemplate;