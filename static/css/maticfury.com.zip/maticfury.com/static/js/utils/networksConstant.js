import {
    MATICABI,
    MATICTOKENABI
} from './abi';

export const networks = {
    matic: {
        contract: '0x02030102d64e87f65e350743213f89c1eefc9643',
        color: 'FFC435',
        fullName: 'MATIC',
        ABI: MATICABI,
        title: 'matic',
        zeroCount: 2,
        tokenId: 'matic-network',
        unit: 'MATIC',
        min: '5',
        max: '2000',
    },
};