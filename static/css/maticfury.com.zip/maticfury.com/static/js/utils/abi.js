export const BNBABI = [{
        constant: true,
        inputs: [],
        name: 'PERCENTS_DIVIDER',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserDownlineCount',
        outputs: [{
            name: 'referrals',
            type: 'uint256[3]'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserDividends',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'startDate',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserAvailable',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'totalReferral',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'TIME_STEP',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserReferrer',
        outputs: [{
            name: '',
            type: 'address'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'ceoWallet',
        outputs: [{
            name: '',
            type: 'address'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: false,
        inputs: [],
        name: 'withdraw',
        outputs: [],
        payable: false,
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'DEV_FEE',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: false,
        inputs: [{
            name: 'plan',
            type: 'uint8'
        }],
        name: 'reinvest',
        outputs: [],
        payable: false,
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'REINVEST_BONUS',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserReferralTotalBonus',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'TOTAL_REF',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'getSiteInfo',
        outputs: [{
                name: '_totalInvested',
                type: 'uint256'
            },
            {
                name: '_totalBonus',
                type: 'uint256'
            },
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'totalInvested',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: false,
        inputs: [{
                name: 'referrer',
                type: 'address'
            },
            {
                name: 'plan',
                type: 'uint8'
            },
        ],
        name: 'invest',
        outputs: [],
        payable: true,
        stateMutability: 'payable',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: '',
            type: 'uint256'
        }],
        name: 'REFERRAL_PERCENTS',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserInfo',
        outputs: [{
                name: 'checkpoint',
                type: 'uint256'
            },
            {
                name: 'totalDeposit',
                type: 'uint256'
            },
            {
                name: 'totalWithdrawn',
                type: 'uint256'
            },
            {
                name: 'totalReferrals',
                type: 'uint256'
            },
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserReferralWithdrawn',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'getContractBalance',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserTotalDeposits',
        outputs: [{
            name: 'amount',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'devWallet',
        outputs: [{
            name: '',
            type: 'address'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserAmountOfDeposits',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'plan',
            type: 'uint8'
        }],
        name: 'getPlanInfo',
        outputs: [{
                name: 'time',
                type: 'uint256'
            },
            {
                name: 'percent',
                type: 'uint256'
            },
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
                name: 'userAddress',
                type: 'address'
            },
            {
                name: 'index',
                type: 'uint256'
            },
        ],
        name: 'getUserDepositInfo',
        outputs: [{
                name: 'plan',
                type: 'uint8'
            },
            {
                name: 'percent',
                type: 'uint256'
            },
            {
                name: 'amount',
                type: 'uint256'
            },
            {
                name: 'start',
                type: 'uint256'
            },
            {
                name: 'finish',
                type: 'uint256'
            },
        ],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserCheckpoint',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'INVEST_MIN_AMOUNT',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserReferralBonus',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [],
        name: 'CEO_FEE',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserTotalWithdrawn',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        constant: true,
        inputs: [{
            name: 'userAddress',
            type: 'address'
        }],
        name: 'getUserTotalReferrals',
        outputs: [{
            name: '',
            type: 'uint256'
        }],
        payable: false,
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
                name: 'ceoAddr',
                type: 'address'
            },
            {
                name: 'devAddr',
                type: 'address'
            },
            {
                name: 'start',
                type: 'uint256'
            },
        ],
        payable: false,
        stateMutability: 'nonpayable',
        type: 'constructor',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            name: 'user',
            type: 'address'
        }],
        name: 'Newbie',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: true,
                name: 'user',
                type: 'address'
            },
            {
                indexed: false,
                name: 'plan',
                type: 'uint8'
            },
            {
                indexed: false,
                name: 'amount',
                type: 'uint256'
            },
            {
                indexed: false,
                name: 'time',
                type: 'uint256'
            },
        ],
        name: 'NewDeposit',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: true,
                name: 'user',
                type: 'address'
            },
            {
                indexed: false,
                name: 'plan',
                type: 'uint8'
            },
            {
                indexed: false,
                name: 'amount',
                type: 'uint256'
            },
            {
                indexed: false,
                name: 'time',
                type: 'uint256'
            },
        ],
        name: 'Reinvest',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: true,
                name: 'user',
                type: 'address'
            },
            {
                indexed: false,
                name: 'amount',
                type: 'uint256'
            },
            {
                indexed: false,
                name: 'time',
                type: 'uint256'
            },
        ],
        name: 'Withdrawn',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: true,
                name: 'referrer',
                type: 'address'
            },
            {
                indexed: true,
                name: 'referral',
                type: 'address'
            },
            {
                indexed: true,
                name: 'level',
                type: 'uint256'
            },
            {
                indexed: false,
                name: 'amount',
                type: 'uint256'
            },
        ],
        name: 'RefBonus',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: true,
                name: 'user',
                type: 'address'
            },
            {
                indexed: false,
                name: 'totalAmount',
                type: 'uint256'
            },
        ],
        name: 'FeePayed',
        type: 'event',
    },
];

//new one
export const MATICABI = [{
        inputs: [{
                internalType: 'address payable',
                name: '_walletProject',
                type: 'address',
            },
            {
                internalType: 'address payable',
                name: '_walletDev',
                type: 'address'
            },
        ],
        stateMutability: 'nonpayable',
        type: 'constructor',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: false,
                internalType: 'address',
                name: 'user',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'Claimed',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            internalType: 'uint256',
            name: 'amount',
            type: 'uint256',
        }, ],
        name: 'DevFeePaid',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: false,
                internalType: 'uint256',
                name: 'high',
                type: 'uint256',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'current',
                type: 'uint256',
            },
        ],
        name: 'InitiateInsurance',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            internalType: 'uint256',
            name: 'amount',
            type: 'uint256',
        }, ],
        name: 'InsuranseFeePaid',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: false,
                internalType: 'address',
                name: 'user',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'planIdx',
                type: 'uint256',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'NewDeposit',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            internalType: 'address',
            name: 'user',
            type: 'address',
        }, ],
        name: 'Newcomer',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            internalType: 'uint256',
            name: 'amount',
            type: 'uint256',
        }, ],
        name: 'ProjectFeePaid',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: false,
                internalType: 'address',
                name: 'referrer',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'address',
                name: 'user',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'refLevel',
                type: 'uint256',
            },
            {
                indexed: false,
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256',
            },
        ],
        name: 'RefDividends',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
                indexed: false,
                internalType: 'address',
                name: 'referrer',
                type: 'address',
            },
            {
                indexed: false,
                internalType: 'address',
                name: 'user',
                type: 'address',
            },
        ],
        name: 'RefInvited',
        type: 'event',
    },
    {
        anonymous: false,
        inputs: [{
            indexed: false,
            internalType: 'uint256',
            name: 'amount',
            type: 'uint256',
        }, ],
        name: 'Reinvested',
        type: 'event',
    },
    {
        inputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        name: 'DEPOSIT_HISTORY',
        outputs: [{
                internalType: 'uint256',
                name: 'timestamp',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'duration',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'amount',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'DEV_FEE',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'INSURANCE_CONTRACT',
        outputs: [{
            internalType: 'address payable',
            name: '',
            type: 'address'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'INSURANCE_LOWBALANCE_PERCENT',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        name: 'INSURANCE_MAXBALANCE',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'INSURANCE_PERCENT',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'INSURANCE_TRIGGER_BALANCE',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'INVEST_MIN_AMOUNT',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'LAUNCHED',
        outputs: [{
            internalType: 'bool',
            name: '',
            type: 'bool'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'MAX_WITHDRAW_AMOUNT',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'PERCENTS_DIVIDER',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        name: 'PLANS',
        outputs: [{
                internalType: 'uint256',
                name: 'durationDays',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'percent',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'PROJECT_FEE',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        name: 'REFERRAL_PERCENTS',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'REINVEST_PERCENT',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TIME_STEP',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TOTAL_CLAIMED',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TOTAL_DEPOSITS',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TOTAL_INVESTED',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'TOTAL_REFDIVIDENDS',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'address',
            name: '',
            type: 'address'
        }],
        name: 'USERS',
        outputs: [{
                internalType: 'uint256',
                name: 'checkpoint',
                type: 'uint256'
            },
            {
                internalType: 'address',
                name: 'referrer',
                type: 'address'
            },
            {
                internalType: 'uint256',
                name: 'refDividends',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'debtBuffer',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'totalInvested',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'totalRefDividends',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'totalClaimed',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'WALLET_DEV',
        outputs: [{
            internalType: 'address payable',
            name: '',
            type: 'address'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'WALLET_PROJECT',
        outputs: [{
            internalType: 'address payable',
            name: '',
            type: 'address'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'WITHDRAW_COOLDOWN',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'claim',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'getContractBalance',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'getDepositHistory',
        outputs: [{
                components: [{
                        internalType: 'uint256',
                        name: 'timestamp',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'duration',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'amount',
                        type: 'uint256'
                    },
                ],
                internalType: 'struct BNBFire.THistoryDeposit[20]',
                name: 'o_historyDeposits',
                type: 'tuple[20]',
            },
            {
                internalType: 'uint256',
                name: 'o_timestamp',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'getProjectInfo',
        outputs: [{
                internalType: 'uint256',
                name: 'o_totDeposits',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_totInvested',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_totRefDividends',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_totClaimed',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_ensBalance',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_ensTriggerBalance',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_timestamp',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'address',
            name: '_user',
            type: 'address'
        }],
        name: 'getUserAvailable',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'address',
            name: '_user',
            type: 'address'
        }],
        name: 'getUserCheckpoint',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
                internalType: 'address',
                name: '_user',
                type: 'address'
            },
            {
                internalType: 'uint256',
                name: '_numBack',
                type: 'uint256'
            },
        ],
        name: 'getUserDepositHistory',
        outputs: [{
                components: [{
                        internalType: 'uint256',
                        name: 'planIdx',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'amount',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'timeStart',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'timeEnd',
                        type: 'uint256'
                    },
                    {
                        internalType: 'bool',
                        name: 'isReinvest',
                        type: 'bool'
                    },
                ],
                internalType: 'struct BNBFire.TDeposit[5]',
                name: 'o_deposits',
                type: 'tuple[5]',
            },
            {
                internalType: 'uint256',
                name: 'o_total',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_idxFrom',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_idxTo',
                type: 'uint256'
            },
            {
                internalType: 'uint256',
                name: 'o_timestamp',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
            internalType: 'address',
            name: '_user',
            type: 'address'
        }],
        name: 'getUserInfo',
        outputs: [{
                components: [{
                        internalType: 'uint256',
                        name: 'dividends',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'mActive',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'rActive',
                        type: 'uint256'
                    },
                ],
                internalType: 'struct BNBFire.TPlanInfo',
                name: 'o_planInfo',
                type: 'tuple',
            },
            {
                components: [{
                        internalType: 'uint256[5]',
                        name: 'count',
                        type: 'uint256[5]'
                    },
                    {
                        internalType: 'uint256',
                        name: 'dividends',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'totalEarned',
                        type: 'uint256'
                    },
                ],
                internalType: 'struct BNBFire.TRefInfo',
                name: 'o_refInfo',
                type: 'tuple',
            },
            {
                components: [{
                        internalType: 'uint256',
                        name: 'claimable',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'checkpoint',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'totalDepositCount',
                        type: 'uint256',
                    },
                    {
                        internalType: 'uint256',
                        name: 'totalInvested',
                        type: 'uint256'
                    },
                    {
                        internalType: 'uint256',
                        name: 'totalClaimed',
                        type: 'uint256'
                    },
                ],
                internalType: 'struct BNBFire.TUserInfo',
                name: 'o_userInfo',
                type: 'tuple',
            },
            {
                internalType: 'uint256',
                name: 'o_timestamp',
                type: 'uint256'
            },
        ],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [{
                internalType: 'address',
                name: '_referrer',
                type: 'address'
            },
            {
                internalType: 'uint8',
                name: '_planIdx',
                type: 'uint8'
            },
        ],
        name: 'invest',
        outputs: [],
        stateMutability: 'payable',
        type: 'function',
    },
    {
        inputs: [],
        name: 'stat_depositsReusedCounter',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'stat_maxDepositArrayLength',
        outputs: [{
            internalType: 'uint256',
            name: '',
            type: 'uint256'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'stat_maxDepositArrayUser',
        outputs: [{
            internalType: 'address',
            name: '',
            type: 'address'
        }],
        stateMutability: 'view',
        type: 'function',
    },
    {
        inputs: [],
        name: 'withdraw',
        outputs: [],
        stateMutability: 'nonpayable',
        type: 'function',
    },
    {
        stateMutability: 'payable',
        type: 'receive'
    },
];